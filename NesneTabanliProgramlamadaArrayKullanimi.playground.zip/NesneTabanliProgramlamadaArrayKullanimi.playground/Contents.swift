import UIKit

class Calisanlar {
    
var numara: Int?
var isim: String?
var isYeri: String?
    
    init(numara: Int, isim: String, isYeri: String){
        self.numara = numara
        self.isim = isim
        self.isYeri = isYeri
    }
}
//ardından bu class içerisinden nesneler oluşturacağız.

var c1 = Calisanlar(numara: 200, isim: "Gazi", isYeri: "Türk Telekom")
var c2 = Calisanlar(numara: 300, isim: "Büşra", isYeri: "Vodafone")
var c3 = Calisanlar(numara: 100, isim: "Firdevs", isYeri: "Turkcell")

var calisanlarListesi = [Calisanlar]()
calisanlarListesi.append(c1)
calisanlarListesi.append(c2)
calisanlarListesi.append(c3)

for c in calisanlarListesi {
    print("Numara: \(c.numara!) - İsim: \(c.isim!) - İş Yeri: \(c.isYeri!)")
}

//filtreleme

var f1 = calisanlarListesi.filter({$0.numara! > 100})
print ("Filtreleme 1")

for c in f1 {
        print("Numara: \(c.numara!) - İsim: \(c.isim!) - İş Yeri: \(c.isYeri!)")

}

var f2 = calisanlarListesi.filter({$0.numara! > 100 && $0.numara! < 250})
print ("Filtreleme 2")

for c in f2 {
        print("Numara: \(c.numara!) - İsim: \(c.isim!) - İş Yeri: \(c.isYeri!)")

}
var f3 = calisanlarListesi.filter({ $0.isim!.contains("a") })
print ("Filtreleme 3")

for c in f3 {
        print("Numara: \(c.numara!) - İsim: \(c.isim!) - İş Yeri: \(c.isYeri!)")

}


//Sıralama olarak da bilinen sorted artan, azalan gibi kıyaslamalar yapar. Filtrelemeden farklı olarak classtan iki farklı nesne almak ve bunları kıyaslamak gerekir.


var f4 = calisanlarListesi.sorted(by: {$0.numara! > $1.numara!})
print("Çalışanların numaralarıyla büyükten küçüğe sıralama")

for c in f4 {
    print("Numara: \(c.numara!) - İsim: \(c.isim!) - İş Yeri: \(c.isYeri!)")
    
}



var f5 = calisanlarListesi.sorted(by: {$0.numara! < $1.numara!})
print("Çalışanların numaralarıyla küçükten büyüğe sıralama")

for c in f5 {
    print("Numara: \(c.numara!) - İsim: \(c.isim!) - İş Yeri: \(c.isYeri!)")
    
}

//metinsel olarak sıralama yapmak istersek

var f6 = calisanlarListesi.sorted(by: {$0.isim! < $1.isim!})
print("Çalışanların isimleriyle küçükten büyüğe sıralama")

for c in f6 {
    print("Numara: \(c.numara!) - İsim: \(c.isim!) - İş Yeri: \(c.isYeri!)")
    
}


var f7 = calisanlarListesi.sorted(by: {$0.isim! > $1.isim!})
print("Çalışanların isimleriyle büyükten küçüğe sıralama")

for c in f7 {
    print("Numara: \(c.numara!) - İsim: \(c.isim!) - İş Yeri: \(c.isYeri!)")
    
}
