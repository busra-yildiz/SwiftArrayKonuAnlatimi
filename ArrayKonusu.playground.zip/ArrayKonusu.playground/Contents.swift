import UIKit

// var hayvanlar = ["Kedi", "Köpek", "Aslan] normalde direk bu şekilde de yazdırabiliriz ama biz array yapısında veri eklemeyi sonradan yapmayı seçtiğimiz için bu array gösterimini pek seçmeyiz.

var hayvanlar = [String]() //bu şekilde sonradan veri ekleyecek şekilde array tanımlaması yaparız.

//Veri ekleme sırasında .append yapısından yardım alırız.

hayvanlar.append("Kedi") //ilk sırada tanımlanan direk 0ncı index olarak yer alır.
hayvanlar.append("Köpek") //1.
hayvanlar.append("Aslan") //2.
print(hayvanlar)


//Veri ekledikten sonra o verilerin yerine başka veriler eklemek isteyebiliriz. O süreçte de güncelleme yapmak gerekir. Güncelleme sırasında değiştireceğimiz değişkenin indexi neredeyse ona göre değişiklik yaparız. Yani;

hayvanlar[0] = "Yeni Kedi"
print(hayvanlar)

//Insert yapısı da .append gibi eklemek anlamına gelir. Fakat bu biraz daha farklı. Çünkü append denildiği zaman direk sona ekler ama ınsert dediğin zaman istediiğin yere ekler.

hayvanlar.insert ("Kanarya", at:1)
print(hayvanlar)

// normalde index birde köpek vardı fakat artık köpek yerine kanarya geçecek ve diğerlerini birer index geriye kaydıracak.

// tabi ki biz bu şekilde tüm verileri ekrana yazdırıyoruz. Sadece tek bir veri yazdırmak istiyorsak da bunun için direk veri okuma yapabiliriz.

print(hayvanlar[2]) // bu satır hayvanlar arrayi içerisinde 2nci indexte yer alan veriyi ekrana yazdır anlamına gelir. Böylece ekrana Köpek yazdırır. Tabi ki bunu bir veriye aktararak da ekrana yazdırma işlemi yapabiliriz.

let a = hayvanlar[0]
print(a) // bu iki satır da veri aktarma yaparak 0ncı indexteki veriyi ekrana yazdırmayı sağlar.



// array yapımızın boyutunu öğrenmek istersek de alt satırdaki gibi yapabiliriz
print("Boyut : \(hayvanlar.count)")


// array yapımızın içi boş mu dolu mu bunu kontrol etmek istediğimiz zaman aşağıdaki gibi bakabiliriz.

print("Boş kontrol : \(hayvanlar.isEmpty)")

//for döngüsüyle array yapısını kullanmak için;
for hayvan in hayvanlar{  //buradaki hayvanlar array ismi hayvan da içindeki değişkenleri simgeler
    print("Sonuç 1 :\(hayvan)")
}



//döngülerde bir de indeks numaralarıyla ekrana yazdırmak istersek;

for (indeks, hayvan) in hayvanlar.enumerated() {
    print ("\(indeks). -> \(hayvan)")
    
}

//array içinden veri silmek için .remove ile sağlarız.
hayvanlar.remove(at: 1)
print(hayvanlar)

//arrayin içinin tamamını silmek için
hayvanlar.removeAll()
print(hayvanlar) //ekrana direk boş köşeli parantez verir.



